package com.referpesa.demo

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.content.Intent

class MainActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val web = WebView(this)
    web.settings.javaScriptEnabled = true
    web.settings.domStorageEnabled = true
    web.webViewClient = WebViewClient()
    web.addJavascriptInterface(object {
      @JavascriptInterface fun share(text: String) {
        runOnUiThread {
          val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
          startActivity(Intent.createChooser(send, "Share referral"))
        }
      }
    }, "Android")
    setContentView(web)
    web.loadUrl("file:///android_asset/index.html")
  }
}
